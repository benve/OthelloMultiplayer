package almostothello.network;

/**
 * Created by IntelliJ IDEA.
 * User: Giacomo Benvenuti
 * Date: 4/30/11
 * Time: 11:07 AM
 * To change this template use File | Settings | File Templates.
 */
public class MaxPlayerException extends Exception {
    public MaxPlayerException(String s) {
        super(s);
    }
}
