package almostothello.network;

/**
 * Created by IntelliJ IDEA.
 * User: lemad85
 * Date: 27/06/11
 * Time: 23.07
 * To change this template use File | Settings | File Templates.
 */
public class CantAddPlayerException extends Throwable {
    public CantAddPlayerException(String s) {
        super(s);
    }
}
