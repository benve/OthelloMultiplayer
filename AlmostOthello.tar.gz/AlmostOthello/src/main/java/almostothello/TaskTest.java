package almostothello;

import java.util.Timer;
import java.util.TimerTask;

/**
 * Created by IntelliJ IDEA.
 * User: giacomo
 * Date: 6/27/11
 * Time: 7:00 PM
 * To change this template use File | Settings | File Templates.
 */
public class TaskTest {

    public static void main(String[] args) {
        Timer timer = new Timer();

        timer.scheduleAtFixedRate(new TimerTask() {
                    @Override
                    public void run() {
                        System.out.println(this.toString());
                        System.out.flush();
                        //this.cancel();
                    }
                }, 0, 1000);

       while (true) {
            try {
                Thread.sleep(10000);
            } catch (InterruptedException e) {
                e.printStackTrace();  //To change body of catch statement use File | Settings | File Templates.
            }
        }

    }

}
